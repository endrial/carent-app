# Rent Car App UI in  <img src='http://sovitpoudel.com.np/wp-content/uploads/2019/01/flutter.png' height='30' width='30' align='top'>

Get the complete code of this UI, and for guidance, you can also watch [this video](https://youtu.be/80vWzQB0Eto).

## Screenshots

<img src='https://github.com/Ronak99/RentCar-App-UI/blob/master/screenshot/s1.png' align='left' width='35%'>

<img src='https://github.com/Ronak99/RentCar-App-UI/blob/master/screenshot/s2.png' align='left' width='35%'>

